package com.mycompany.caja;

public class MostrarCaja {

    public static void main(String[] args) {

        Caja Micaja = new Caja(4, 5, 6);

        System.out.println("El volumen de la caja es: " + Micaja.volumen());
    }

}
