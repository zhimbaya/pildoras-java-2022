
public class HolaMundo {

    public static void main(String[] args) {

        var nombre = "Karla";
        var apellido = "Esparza";
        
        System.out.println(nombre + " " + apellido);
        System.out.println("Nueva linea: \n" + nombre);
        System.out.println("Tabulador: \t" + nombre);
        System.out.println("Retroceso: \b\b" + nombre);
        System.out.println("Retorno de carro: \r" + nombre);
        System.out.println("Comilla simple: \'" + nombre + "\'");
        System.out.println("Comilla doble: \"" + nombre + "\"");
        
        System.out.println("saludos");
        System.out.print("adios");
        System.out.println("nos vemos");
    }
}
