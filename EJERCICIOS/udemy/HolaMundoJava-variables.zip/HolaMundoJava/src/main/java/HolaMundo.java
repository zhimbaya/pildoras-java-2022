
public class HolaMundo {

    public static void main(String[] args) {
        
        String saludar = "saludos desde Java";
        
        System.out.println(saludar);
        System.out.println(saludar);
        System.out.println(saludar);
        
        var despedirse = "hasta luego";
        System.out.println(despedirse);
        
        var numero = 1;
        System.out.println(numero);
        
    }
}
