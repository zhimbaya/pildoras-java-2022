/*
Este es un comentarios de varias lineas
 */

//Comentario de una sola linea
public class HolaMundo {

    public static void main(String[] args) {
        System.out.println("Hola mundo desde java");
    }
}
