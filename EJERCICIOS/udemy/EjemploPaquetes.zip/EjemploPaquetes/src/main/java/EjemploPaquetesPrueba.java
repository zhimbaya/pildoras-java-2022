
//import com.gm.Utileria;
//import com.gm.*;

import static com.gm.Utileria.imprimir;

public class EjemploPaquetesPrueba {

    public static void main(String[] args) {
        //Utilizando el nombre de la clase completamente calificado 
        //fully qualified name
        //com.gm.Utileria.imprimir("Hola");
        
        //haciendo un import de la clase
        //Utileria.imprimir("hola");
        
        //haciendo un import static
        imprimir("hola");
    }
}
