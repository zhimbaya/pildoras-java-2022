package com.gm;

public class Utileria {
    public static void imprimir(String s){
        System.out.println("s = " + s);
    }
}
