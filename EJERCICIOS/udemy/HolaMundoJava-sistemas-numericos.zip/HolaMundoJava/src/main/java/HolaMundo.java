
import java.util.Scanner;

public class HolaMundo {

    public static void main(String[] args) {

        var numeroDecimal = 10;
        System.out.println("numeroDecimal = " + numeroDecimal);

        var numeroOctal = 012;
        System.out.println("numeroOctal = " + numeroOctal);
        
        var numeroHexadecimal = 0xA;
        System.out.println("numeroHexadecimal = " + numeroHexadecimal);
        
        var numberoBinario = 0b1010;
        System.out.println("numberoBinario = " + numberoBinario);
    }
}
