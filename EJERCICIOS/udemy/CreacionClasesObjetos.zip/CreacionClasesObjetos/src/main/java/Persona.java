public class Persona {
    //Atributos de nuestra clase
    String nombre;
    String apellido;
    
    //Metodo de la clase
    //Lo usaran los objetos de esta clase
    public void desplegarNombres( ){
        System.out.println("nombre:" + nombre);
        System.out.println("apellido:" + apellido);
    }
    
}
