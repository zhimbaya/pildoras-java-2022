
import java.util.Scanner;

public class HolaMundo {

    public static void main(String[] args) {

      for(var i = 0 ; i < 3 ; i++){
          System.out.println("i = " + i);
      }
      
    }
}
