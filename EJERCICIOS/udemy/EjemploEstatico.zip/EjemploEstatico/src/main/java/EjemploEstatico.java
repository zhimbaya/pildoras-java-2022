public class EjemploEstatico {
    
}
