
public class HolaMundo {

    public static void main(String[] args) {

        var saludosDesdeJava = "Hola desde Java";
        System.out.println( saludosDesdeJava );
        
        int _holaDesde1Java ;
        float $adios;
        char adios;
        char a123dios;
        
        
    }
}
