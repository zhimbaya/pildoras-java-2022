public class Aritmetica {
    
    public int sumar(int a, int b){
        int resultado = a + b;
        return resultado;
    }
}
